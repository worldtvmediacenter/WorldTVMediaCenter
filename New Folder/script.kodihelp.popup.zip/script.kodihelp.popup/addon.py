import xbmcaddon
import xbmcgui
import xbmc
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


line1 = "Wait For World TV To Finish Loading Screen "
line2 = "We hope you enjoy World TV"
line3 = "Please Select The Ingore To Open World TV Or Check for The Latest Updates"




choice = xbmcgui.Dialog().yesno(addonname, line1, line2, line3, yeslabel='Check For Updates',nolabel='Ingore Message')
if choice == 1:
	xbmc.executebuiltin("ActivateWindow(10001,plugin://plugin.video.worldtvwizard-1.0.0,return)") ##<--change to your plugin|
elif choice == 0:
	xbmcgui.Dialog().ok('[COLOR dodgerblue] Please Hit Ingore To Follow Next Screen[/COLOR]','[COLOR orange]Thanks You For Your Support Check Us Out At www.ajgsportstalk.com For The Latest [/COLOR]','')

	
	
# For color chart go here http://forum.kodi.tv/showthread.php?tid=210837
# To use color---- [COLOR colorname]blah blah blah [/COLOR]
# Colors for text can be used anywhere where text is inbetween--- '' and ""
# For easy copy and paste [COLOR ] [/COLOR]  <---dont forget to put the color name :)

###########thanks to W Hoffman for helping me when i hit a wall###################




