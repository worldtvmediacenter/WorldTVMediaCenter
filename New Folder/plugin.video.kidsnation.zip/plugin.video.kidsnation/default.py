# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Youtube Channel
# (c) 2015 - Simple TechNerd
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.kidsnation'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')


channellist=[
        ("Kids Nation","channel/UCGH-Nh6B9EXTKazaVOtkFBg", 'http://worldtvmediacenter.comli.com/world%20tv%20media%20center%20picture%20zips/Untitled.jpg'),
		("Disney Theme Parks","channel/UCdK0jg7DtqqkF1bu3PlINEg", 'https://lh5.googleusercontent.com/-6eYXqjDgtwY/AAAAAAAAAAI/AAAAAAAAAJI/Ab7FXkEJHfI/s0-c-k-no-ns/photo.jpg'),
	    ("Cartoons List","channel/UCAlHZ_-vE9PUDj4K6iPVIxg", 'http://wac.450f.edgecastcdn.net/80450F/1025kiss.com/files/2011/06/Capture11-150x150.png'),
		("Disney World","user/PopSong1", 'http://www.classywallpapers.com/wp-content/uploads/2015/11/Walt-Disney-World-HD-1-150x150.jpg?489fcf'),
		("Disney Channel","user/disneychannel", 'https://static.apkupdate.com/images/cover/com.disney.datg.videoplatforms.android.watchdc.png'),
		("Disney Parks","user/DisneyParks", 'https://i1.wp.com/www.latestnewsexplorer.com/wp-content/uploads/2014/10/Walt-Disney-Logo.jpg?resize=150%2C150&ssl=1'),
		("Disney Rides","user/InsideTheMagic", 'http://www.themainstreetmouse.com/wp-content/uploads/2014/06/Small-World-150x150.png'),
		("Disney 360","user/Asianjma123", 'http://www.themainstreetmouse.com/wp-content/uploads/2014/04/frozenprincess1-150x150.jpg'),
		("Disney Pictures ","channel/UCz1CQo-ra32ddE3dQBnx4wA",'http://fullhdpictures.com/wp-content/uploads/2016/02/Disney-Logos-150x150.jpg'),
		
]
 



# Entry point
def run():
    plugintools.log("kidsnation.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("kidsnation.main_list "+repr(params))

for name, id, icon in channellist:
	plugintools.add_item(title=name,url="plugin://plugin.video.youtube/"+id+"/",thumbnail=icon,folder=True )
	



run()